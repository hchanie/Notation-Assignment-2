package notation;
import java.util.ArrayList;

public class NotationStack<T> implements StackInterface<T>{
	private static final int DEFAULTCAPACITY = 20;
	private T[] data;
	private int maxSize;
	private int size = 0;
	private int top = -1;

	/**
	 * 
	 * Noatation Stack Constructor
	 * 
	 * @param int  size an integer for size
	 *
	 */
	@SuppressWarnings("unchecked")
	NotationStack(int size) {

		this.maxSize = size;

		top = -1;
		data = (T[]) new Object[size];

	}

	/**
	 * 
	 * default notation Stack Constructor
	 *
	 *
	 */

	@SuppressWarnings("unchecked")
	NotationStack() {
		this.maxSize = 5;
		top = -1;

		data = (T[]) new Object[DEFAULTCAPACITY];

	}

	/**
	 * Determines if Stack is empty
	 * 
	 * @return true if Stack is empty, false if not
	 */
	public boolean isEmpty() {

		if (size == 0) {
			return true;
		}

		else
			return false;

	}

	/**
	 * Determines if Stack is full
	 * 
	 * @return true if Stack is full, false if not
	 */
	public boolean isFull() {
		if (size >= data.length) {
			return true;
		} else {
			return false;
		}

	}

	/**
	 * Deletes and returns the element at the top of the Stack
	 * 
	 * @return value the element at the top of the Stack
	 */
	public T pop() throws StackUnderflowException {
		if (size == 0) {
			throw new StackUnderflowException("Stack is Empty");
		}

		else {
			size = size - 1;

			System.arraycopy(data, 0, data, 0, size);
		}
		T value = data[size];
		return value;

	}

	/**
	 * Returns the element at the top of the Stack, does not pop it off the Stack
	 * 
	 * @return the element at the top of the Stack
	 */
	public T top() throws StackUnderflowException {

		if (size <= 0) {
			throw new StackUnderflowException("Stack is Empty");
		}
		else

			return data[size - 1];

	}

	/**
	 * Number of elements in the Stack
	 * 
	 * @return size the number of elements in the Stack
	 */
	public int size() {

		return size;
	}

	/**
	 * Adds an element to the top of the Stack
	 * 
	 * @param e the element to add to the top of the Stack
	 * @return true if the add was successful, false if not
	 */
	public boolean push(T e) throws StackOverflowException {
		if (size >= data.length) {
			throw new StackOverflowException("Stack is full");
		}
		data[size++] = e;
		top = top + 1;
		return true;

	}

	/**
	 * Returns the string representation of the elements in the Stack, the beginning
	 * of the string is the bottom of the stack Place the delimiter between all
	 * elements of the Stack
	 * 
	 * @return string representation of the Stack from bottom to top with elements
	 *         separated with the delimiter
	 */
	public String toString(String delimiter) {
		String string = "";
		int i;
		for (i = 0; i < size - 1; i++) {
			string += data[i] + delimiter;
		}
		string += data[i];
		return string;

	}

	/**
	 * Fills the Stack with the elements of the ArrayList, First element in the
	 * ArrayList is the first bottom element of the Stack
	 * 
	 * @param list elements to be added to the Stack from bottom to top
	 */

	public void fill(ArrayList<T> list) {
		for (int i = 0; i < list.size(); i++) {
			data[size++] = (T) list.get(i);
			top = top + 1;
		}

	}

	/**
	 * Returns the elements of the Stack in a string from bottom to top, the
	 * beginning of the String is the bottom of the stack
	 * 
	 * @return an string which represent the Objects in the Stack from bottom to top
	 */

	public String toString() {
		String string = "";
		for (int i = 0; i < size; i++) {
			string += data[i];

		}
		return string;
	}

}
