package notation;
/**
 * 
 * @author hunegnaw
 *
 */

public class InvalidNotationFormatException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public InvalidNotationFormatException() {
		
	}
/** 
*  constructor for Invalid Notation Format Exception
*  @param message The message that will be displayed for the exception
*/	
	InvalidNotationFormatException(String message){
	super(message);
}	

}
