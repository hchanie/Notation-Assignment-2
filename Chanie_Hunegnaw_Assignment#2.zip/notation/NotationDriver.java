package notation;

public class NotationDriver {

	public static void main(String[] args) {
		NotationStack<String> x = new NotationStack<String>(10);
		   x.push("Hunegnaw");
			x.push("Chanie ");
			System.out.println(x.toString("_________"));
			x.pop();
			System.out.println(x.toString("_______"));
			x.pop();
			System.out.println(x.toString());
			
			
		}
	}


