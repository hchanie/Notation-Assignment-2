package notation;
/**
 * 
 * @author hunegnaw
 *
 */
public class QueueOverflowException extends RuntimeException {

	public QueueOverflowException() {
		
	}
/** 
*  constructor for Queue Overflow Exception
*  @param message The message that will be displayed for the exception
*/	
	QueueOverflowException(String message){
	super(message);
}	

}
