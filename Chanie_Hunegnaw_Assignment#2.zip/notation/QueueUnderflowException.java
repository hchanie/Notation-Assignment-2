package notation;

public class QueueUnderflowException extends RuntimeException{
	
	public QueueUnderflowException() {
		
	}
/** 
*  constructor for Queue Underflow Exception
*  @param message The message that will be displayed for the exception
*/	
	QueueUnderflowException(String message){
	super(message);
}	

}
