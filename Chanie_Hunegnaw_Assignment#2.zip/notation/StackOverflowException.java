package notation;
/**
 * 
 * @author hunegnaw
 *
 */

public class StackOverflowException extends RuntimeException{

	public StackOverflowException() {
		
	}
/** 
*  constructor for Stack Overflow Exception
*  @param message The message that will be displayed for the exception
*/	
	StackOverflowException(String message){
	super(message);
}	
}
