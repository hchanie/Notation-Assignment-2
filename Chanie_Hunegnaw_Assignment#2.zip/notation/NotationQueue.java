package notation;
/**
 * 
 * @author hunegnaw
 *
 * @param <T>
 */
import java.util.ArrayList;
public class NotationQueue <T>implements QueueInterface<T>{
	private T[] data;
	private int size = 10;
	private int Nodes = 0;
	private int f = 0;
	private int rear = 0;
	@SuppressWarnings("unused")
	private int frontLocation = 0;

	@SuppressWarnings("unchecked")
	NotationQueue() {

		data = (T[]) new Object[size];

	}

	/**
	 * 
	 * NotationQueue Constructor
	 * @param int n an integer for size
	 *
	 */

	@SuppressWarnings("unchecked")
	public NotationQueue(int n) {
		size = n;
		data = (T[]) new Object[n];
	}

	/**
	 * Determines if Queue is empty
	 * 
	 * @return true if Queue is empty, false if not
	 */
	public boolean isEmpty() {
		if (Nodes == 0) {
			return true;
		} else
			return false;
	}

	/**
	 * Determines if the Queue is full
	 * 
	 * @return true if the Queue is full, false if not
	 */
	public boolean isFull() {
		if (Nodes >= data.length) {
			// throw new StackOverflowException("Stack is full");
			return true;
		} else
			return false;
	}

	/**
	 * Deletes and returns the element at the front of the Queue
	 * 
	 * @return value the element at the front of the Queue
	 */

	public T dequeue() throws QueueUnderflowException {
		
		int newfront;
		if (Nodes == 0) {
			throw new QueueUnderflowException("Stack is Empty");
		}

		else {
			newfront = f;
			f = (f + 1) % size;
			Nodes = Nodes - 1;

		}
		T value = data[newfront];
		return value;
	}

	/**
	 * Number of elements in the Queue
	 * 
	 * @return Nodes the number of elements in the Queue
	 */
	
	public int size() {
		return Nodes;
	}

	/**
	 * Adds an element to the end of the Queue
	 * 
	 * @param e the element to add to the end of the Queue
	 * @return true if the add was successful, false if not
	 */

	public boolean enqueue(T e) throws QueueOverflowException {
		if (Nodes >= data.length) {
			throw new QueueOverflowException("Queue is full");
		}

		else {
			Nodes = Nodes + 1;
			data[rear] = e;
			rear = (rear + 1) % size;

		}

		return true;
	}

	/**
	 * Returns the string representation of the elements in the Queue, the beginning
	 * of the string is the front of the queue Place the delimiter between all
	 * elements of the Queue
	 * 
	 * @return string representation of the Queue with elements separated with the
	 *         delimiter
	 */
	public String toString(String delimiter) {
		String string = "";
		for (int i = 0; i < size && data[i] != null; i++) {
			string += data[i];
			if (i < Nodes - 1)
				string += delimiter;
		}
		return string;
	}

	/**
	 * Returns the string representation of the elements in the Queue, the beginning
	 * of the string is the front of the queue
	 * 
	 * @return string representation of the Queue with elements
	 */

	public String toString() {
		String string = "";
		for (int i = 0; i < size && data[i] != null; i++) {
			string += data[i];
		}
		return string;
	}

	/**
	 * Fills the Queue with the elements of the ArrayList, First element in the
	 * ArrayList is the first element in the Queue
	 * 
	 * @param list elements to be added to the Queue
	 */
	public void fill(ArrayList list) {
		for (int i = 0; i < list.size(); i++) {
			data[i] = (T) list.get(i);
			Nodes++;

		}

	}
}

