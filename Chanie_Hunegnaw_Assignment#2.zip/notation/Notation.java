package notation;
/**
 * 
 * @author hunegnaw
 *
 */

public class Notation {
//	static private String expression;
	private static NotationStack<Character> stack = new NotationStack<Character>();
	private static NotationQueue<Character> queue = new NotationQueue<Character>();

	/*
	 * public Notation(String InfixNotation) { expression=InfixNotation;
	 * 
	 * }
	 */

	
	/**
	 * 
	 * Method which converts Infix expressions to postfix expressions
	 * 
	 * @param infix infix expression
	 * @throws InvalidNotationFormatException,QueueOverflowException,QueueUnderflowException,StackOverflowException,StackUnderflowException
	 * @return postfix expression
	 */
	public static String convertInfixToPostfix(String infix) throws 
	InvalidNotationFormatException,
	QueueOverflowException, QueueUnderflowException,
	StackOverflowException, StackUnderflowException {

		String postfixString = "";

		for (int index = 0; index < infix.length(); index++) {
			char value = infix.charAt(index);
			if (value == '(') {
				stack.push('(');
			}
			/*
			 * else if(Character.isDigit(value)) { NotationQueue.enqueue(value);
			 * 
			 * }
			 */
			else if (value == ')') {
				Character oper = stack.top();

				while (!(oper.equals('(')) && !(stack.isEmpty())) {
					stack.pop();
					postfixString += oper.charValue();
					if (!stack.isEmpty()) {
						oper = stack.top();
						stack.pop();
					} else
						throw new InvalidNotationFormatException("The notation is invalid");
				}

			} else if (value == '+' || value == '-') {
				if (stack.isEmpty()) {
					stack.push(value);
				} else {
					Character oper = stack.top();
					while (!(stack.isEmpty() || oper.equals(('(')) || oper.equals((')')))) {
						oper = stack.pop();
						postfixString += oper.charValue();
					}
					stack.push(value);
				}
			} else if (value == '*' || value == '/') {
				if (stack.isEmpty()) {
					stack.push(value);
				} else {
					Character oper = stack.top();

					while (!oper.equals(('(')) && !oper.equals(('+')) && !oper.equals(('-')) && !stack.isEmpty()) {
						oper = stack.pop();
						postfixString += oper.charValue();
					}
					stack.push(value);
				}
			} else {
				postfixString += value;
			}
		}

		while (!stack.isEmpty()) {
			Character oper = stack.top();
			if (!oper.equals(('('))) {
				stack.pop();
				postfixString += oper.charValue();
			}
		}
		return postfixString;
	}

	/**
	 * 
	 * Method which converts Postfix expressions to infix expressions
	 * 
	 * @param postfix postfix expression
	 * @throws InvalidNotationFormatException,QueueOverflowException,QueueUnderflowException,StackOverflowException,StackUnderflowException
	 * @return Infix expression
	 */

	public static String convertPostfixToInfix(String postfix)
			throws InvalidNotationFormatException, StackOverflowException, StackUnderflowException {

		String infixString= "";
		NotationStack<String> stack1 = new NotationStack <String>();

		for (int index = 0; index < postfix.length(); index++) {

			char value = postfix.charAt(index);
			if (value == ' ')
				continue;

			else if (Character.isDigit(value))
				stack1.push("" + value);

			else if (value == '+' || value == '*' || value == '/' || value == '-') {

				if (stack1.size() < 2)
					throw new InvalidNotationFormatException(
							"This should have thrown an InvalidNotationFormatException");

				else {
					String Loperator;
					String Roperator;
					String operator = "";
					Loperator = stack1.pop();

					Roperator = stack1.pop();
					operator = "(" + Roperator + value + Loperator + ")";
					stack1.push(operator);

				}

			}
		}

		return infixString += stack1.pop();

	}

	/**
	 * 
	 * Method which evaluates postfix expressions
	 * 
	 * @param postfix postfix expression
	 * @throws InvalidNotationFormatException,QueueOverflowException,QueueUnderflowException,StackOverflowException,StackUnderflowException
	 * @return evaluation final answer
	 */
	public static double evaluatePostfixExpression(String postfix) throws InvalidNotationFormatException {

		double evaluation = 0.0;
		NotationStack<String> stack = new NotationStack<String>();

		for (int index = 0; index < postfix.length(); index++) {

			char value = postfix.charAt(index);
			if (value == ' ')
				continue;

			else if (Character.isDigit(value))
				stack.push("" + value);

			else if (value == '+' || value == '*' || value == '/' || value == '-') {

				if (stack.size() < 2)
					throw new InvalidNotationFormatException(
							"This should have thrown an InvalidNotationFormatException");

				else {

					String Loperator;
					String Roperator;
					Loperator = stack.pop();
					double b = Double.parseDouble(Loperator);
					Roperator = stack.pop();
					double a = Double.parseDouble(Roperator);

					switch (value) {

					case '+':
						evaluation = b + a;
						break;

					case '-':
						evaluation = a - b;
						break;

					case '*':
						evaluation = b * a;
						break;

					case '/':
						evaluation = a / b;
						break;
					}
					stack.push("" + evaluation);
				}

			}

		}
		if (stack.size() > 1) {
			throw new InvalidNotationFormatException("The notation is invalid");
		}

		else {
			return evaluation;
		}
	}

	public static double evaluateInfixExpression(String infixExpr)throws InvalidNotationFormatException {
		String string = convertInfixToPostfix(infixExpr);

		return evaluatePostfixExpression(string);
	}
	
}
