package notation;

public class StackUnderflowException extends RuntimeException {
	
	public StackUnderflowException() {
		
	}
/** 
*  constructor for Stack Underflow Exception
*  @param message The message that will be displayed for the exception
*/	
	StackUnderflowException(String message){
	super(message);
}	

}
